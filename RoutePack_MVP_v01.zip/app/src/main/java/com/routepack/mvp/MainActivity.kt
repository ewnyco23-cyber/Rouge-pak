package com.routepack.mvp

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

data class PackageItem(val code: String, val address: String)

class MainActivity : Activity() {
    private val packages = mutableListOf<PackageItem>()
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "RoutePack"
            textSize = 30f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "Escanea y organiza tus paquetes por dirección"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }

        val code = EditText(this).apply {
            hint = "Código del paquete"
            inputType = 1
        }

        val address = EditText(this).apply {
            hint = "Dirección de entrega"
            inputType = 1
        }

        val add = Button(this).apply {
            text = "Agregar paquete"
            setOnClickListener {
                val c = code.text.toString().trim()
                val a = address.text.toString().trim()
                if (c.isNotEmpty() && a.isNotEmpty()) {
                    packages.add(PackageItem(c, a))
                    code.text.clear()
                    address.text.clear()
                    refreshList()
                } else {
                    Toast.makeText(this@MainActivity, "Completa código y dirección", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val route = Button(this).apply {
            text = "Preparar ruta"
            setOnClickListener {
                Toast.makeText(
                    this@MainActivity,
                    "Ruta preparada con ${packages.size} paquetes",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(code)
        root.addView(address)
        root.addView(add)
        root.addView(route)
        root.addView(list)

        setContentView(root)
    }

    private fun refreshList() {
        list.removeAllViews()
        packages.forEachIndexed { index, item ->
            val row = TextView(this).apply {
                text = "${index + 1}. ${item.code}\n${item.address}"
                textSize = 16f
                setPadding(12, 18, 12, 18)
            }
            list.addView(row)
        }
    }
}
