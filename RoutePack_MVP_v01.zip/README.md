# RoutePack MVP

Aplicación Android inicial para registrar paquetes y preparar rutas por dirección.

## Funciones iniciales
- Registrar código del paquete.
- Registrar dirección.
- Mostrar paquetes registrados.
- Preparación para escáner y ordenamiento de rutas.

## Próximo paso
Agregar escaneo de códigos de barras/QR, geocodificación y optimización de ruta.
